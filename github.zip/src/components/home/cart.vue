<template>
  <div>
      <p>cart</p>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
