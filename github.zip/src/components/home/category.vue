<template>
  <div class="container">
      <p>category</p>
  </div>
</template>

<script>
export default {
    
}
</script>

<style>

</style>
