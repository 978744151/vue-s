export default {
    a :function(){
        const url = 'https://mall.wojianwang.com';
        return url
    }
}
